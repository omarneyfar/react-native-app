import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { themeGlobal } from '../../../styles/themeGlobal'

const promotions = () => {
  return (
    <View style={themeGlobal.baseStyles.container}>
      <Text>promotions</Text>
    </View>
  )
}

export default promotions

const styles = StyleSheet.create({})